// controllers/reportController.js
// Gera relatórios financeiros restritos à empresa logada

import Transaction from "../models/Transaction.js";

export const getCompanyReport = async (req, res) => {
  try {
    const empresaId = req.user.empresaId; // pega a empresa do token JWT

    // 🔍 Busca transações apenas da empresa logada
    const transactions = await Transaction.find({ empresaId });

    // 📈 Cálculo simples de receitas e despesas
    const totalReceitas = transactions
      .filter(t => t.tipo === "receita")
      .reduce((acc, t) => acc + t.valor, 0);

    const totalDespesas = transactions
      .filter(t => t.tipo === "despesa")
      .reduce((acc, t) => acc + t.valor, 0);

    const saldoAtual = totalReceitas - totalDespesas;

    res.status(200).json({
      empresaId,
      totalReceitas,
      totalDespesas,
      saldoAtual,
      quantidadeTransacoes: transactions.length
    });

  } catch (err) {
    console.error("Erro ao gerar relatório:", err);
    res.status(500).json({ message: "Erro ao gerar relatório financeiro" });
  }
};
