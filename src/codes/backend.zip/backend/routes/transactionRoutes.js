import express from "express";
import { companyScopeMiddleware } from "../middlewares/companyScopeMiddleware.js";
import * as transactionController from "../controllers/transactionController.js";
import Transaction from "../models/Transaction.js";

const router = express.Router();

// Rota protegida pelo escopo da empresa
router.get("/", companyScopeMiddleware(Transaction), transactionController.getAllTransactions);

export default router;
